"use client";

import Bubbles from "./Bubbles";

export default function BubblesPage({ coins }: any) {
  return <Bubbles coins={coins} />;
}
